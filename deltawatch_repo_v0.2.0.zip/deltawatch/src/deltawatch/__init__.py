"""DeltaWatch: reproducible, quality-controlled Sentinel-2 NDVI pipeline."""

__version__ = "0.2.0"
