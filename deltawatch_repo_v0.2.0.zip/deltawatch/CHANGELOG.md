# Changelog

All notable changes to this project are documented here. Versions follow [Semantic Versioning](https://semver.org/).

## [0.2.0] - 2026-11-23
### Added
- Optional locked benchmark (`deltawatch benchmark`): past-only baselines A (latest within 30 days) and
  B (median of up to 3 within 30 days) on non-overlapping hidden 20 px blocks, with validation/test
  targets and seeds locked in config before scoring, an evaluator isolated from predictors, and
  intersection metrics. Tests cover past-only context, truth isolation, deterministic masks,
  hand-calculated MAE/RMSE, empty support and coverage arithmetic.

### Fixed
- `pytest` now finds the package without installation (`pythonpath = ["src"]`); the first fresh
  Colab run failed test collection with `ModuleNotFoundError: deltawatch`.

## [0.1.0] - 2026-11-23
### Added
- Config-driven STAC discovery on Earth Search `sentinel-2-c1-l2a`, single MGRS tile (36RTV).
- SCL-only AOI screening, one item per acquisition date with a documented tie-break, deterministic
  date selection spread over a configurable window, frozen manifest with SHA-256 fingerprint.
- Windowed COG reads on a reference grid snapped to the red 10 m grid; nearest-neighbour SCL
  resampling; scale/offset reconciliation between STAC and raster metadata (fails on conflict).
- Per-date NDVI (float32, NaN nodata) and valid-mask (uint8) GeoTIFFs with provenance tags and
  read-back verification; QA CSV, QA panel with attribution, run metadata with measured timings/memory.
- Fingerprint-checked reuse of cached outputs.
- CLI (`deltawatch discover`, `deltawatch run`), offline pytest suite, optional live smoke test,
  ruff, pre-commit and GitHub Actions CI configuration.

### Decisions
- Selection window narrowed to 2025-03-20..2025-06-29 so later benchmark targets have earlier
  context within 30 days (full-season spread left gaps up to 37 days).
- NDVI is a valid observation only where red > 0 and nir > 0; slightly negative reflectances are
  kept and counted, never clipped (found on 2025-04-05 and 2025-04-17).
