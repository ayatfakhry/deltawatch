"""Shared synthetic fixtures. No network is used by any test outside tests/live/."""

from __future__ import annotations

import numpy as np
import pytest
import rasterio
from rasterio.transform import from_origin

from deltawatch.raster import Grid

CRS = "EPSG:32636"


@pytest.fixture
def grid10() -> Grid:
    # 6 x 8 pixels of 10 m, origin on the 10 m tile grid (and on the 20 m grid).
    return Grid(CRS, from_origin(300000.0, 3426000.0, 10.0, 10.0), (6, 8))


@pytest.fixture
def scl20_path(tmp_path):
    """A 20 m categorical raster covering grid10 with a 1-pixel margin, distinct class per pixel."""
    arr = np.array(
        [[0, 1, 2, 3, 4, 5], [6, 7, 8, 9, 10, 11], [4, 5, 6, 4, 5, 6], [3, 8, 9, 10, 4, 4], [5, 5, 5, 5, 5, 5]],
        dtype=np.uint8,
    )
    path = tmp_path / "scl20.tif"
    with rasterio.open(
        path,
        "w",
        driver="GTiff",
        height=arr.shape[0],
        width=arr.shape[1],
        count=1,
        dtype="uint8",
        crs=CRS,
        transform=from_origin(299980.0, 3426020.0, 20.0, 20.0),
        nodata=0,
    ) as dst:
        dst.write(arr, 1)
    return path, arr


@pytest.fixture
def dn10_path(tmp_path):
    """A 10 m uint16 DN raster larger than grid10, with stored scale/offset like Collection 1."""
    rng = np.random.default_rng(0)
    arr = rng.integers(1000, 5000, size=(20, 20), dtype=np.uint16)
    arr[5, 5] = 0  # nodata
    path = tmp_path / "dn10.tif"
    with rasterio.open(
        path,
        "w",
        driver="GTiff",
        height=20,
        width=20,
        count=1,
        dtype="uint16",
        crs=CRS,
        transform=from_origin(299950.0, 3426050.0, 10.0, 10.0),
        nodata=0,
    ) as dst:
        dst.write(arr, 1)
        dst.scales = (0.0001,)
        dst.offsets = (-0.1,)
    return path, arr
