"""End-to-end run_core on synthetic local rasters: no network, exercises the real code path."""

import numpy as np
import pandas as pd
import pytest
import rasterio
from rasterio.transform import from_origin

from deltawatch.config import load_config
from deltawatch.manifest import save_manifest
from deltawatch.pipeline import run_core

CRS = "EPSG:32636"


def _write(path, arr, res, origin, nodata, scale=None):
    with rasterio.open(
        path,
        "w",
        driver="GTiff",
        height=arr.shape[0],
        width=arr.shape[1],
        count=1,
        dtype=arr.dtype.name,
        crs=CRS,
        transform=from_origin(*origin, res, res),
        nodata=nodata,
    ) as d:
        d.write(arr, 1)
        if scale:
            d.scales, d.offsets = (scale[0],), (scale[1],)


@pytest.fixture
def scene(tmp_path):
    """Two dates; date 2 has a cloud patch, a nodata pixel and one negative-NIR pixel."""
    items = []
    for k, date in enumerate(["2025-04-05", "2025-04-17"]):
        red = np.full((12, 12), 1800, np.uint16)  # 0.08 reflectance
        nir = np.full((12, 12), 5100, np.uint16)  # 0.41 reflectance
        scl = np.full((6, 6), 4, np.uint8)
        if k == 1:
            scl[0:2, 0:2] = 9  # cloud -> 4x4 invalid at 10 m
            red[10, 10] = 0  # nodata
            red[11, 11], nir[11, 11] = 1066, 958  # negative NIR -> out-of-range NDVI
        paths = {}
        for role, arr, res, nod, sc in [
            ("red", red, 10, 0, (0.0001, -0.1)),
            ("nir", nir, 10, 0, (0.0001, -0.1)),
            ("scl", scl, 20, 0, None),
        ]:
            p = tmp_path / f"{role}_{date}.tif"
            _write(p, arr, res, (300000.0, 3426000.0), nod, sc)
            paths[role] = p
        items.append(
            {
                "id": f"S2X_T36RTV_{date}",
                "date": date,
                "datetime": f"{date}T08:41:00Z",
                "assets": {
                    r: {"href": str(p), "scale": None if r == "scl" else 0.0001, "offset": None if r == "scl" else -0.1}
                    for r, p in paths.items()
                },
            }
        )
    m = {
        "manifest_version": 1,
        "frozen_at_utc": "x",
        "stac": {"collection": "sentinel-2-c1-l2a"},
        "grid": {"crs": CRS, "transform": [10.0, 0.0, 300000.0, 0.0, -10.0, 3426000.0], "shape": [12, 12]},
        "quality_policy": {"scl_usable_classes": [4, 5, 6]},
        "items": items,
    }
    save_manifest(m, tmp_path / "manifest.json")
    return tmp_path


def test_run_core_end_to_end(scene):
    cfg = load_config("config/default.yaml")
    res = run_core(cfg, scene / "manifest.json", scene / "out")
    qa = res["qa"].set_index("date")
    assert qa.loc["2025-04-05", "valid_fraction"] == 1.0
    assert qa.loc["2025-04-05", "ndvi_p50"] == pytest.approx((0.41 - 0.08) / 0.49, abs=1e-4)
    d2 = qa.loc["2025-04-17"]
    assert d2["valid_fraction"] == pytest.approx((144 - 16 - 2) / 144, abs=1e-4)
    assert d2["nodata_red_px"] == 1 and d2["nodata_marked_valid_px"] == 0
    assert d2["ndvi_out_of_range_px"] == 1 and d2["ndvi_out_of_range_with_positive_refl_px"] == 0
    assert d2["scl_9"] == 16 and d2["valid_fraction_if_dilated"] < d2["valid_fraction"]
    assert qa["roundtrip_ok"].all() and qa["valid_ndvi_max_abs"].max() <= 1
    out = scene / "out"
    assert (out / "qa_per_date.csv").exists() and (out / "qa_ndvi_panel.png").exists()
    assert res["meta"]["memory"]["measured_peak_process_rss_MB"] > 0
    with rasterio.open(out / "ndvi" / "ndvi_2025-04-17.tif") as ds:
        a = ds.read(1)
        assert np.isnan(ds.nodata) and np.isnan(a[0:4, 0:4]).all()  # cloud stays NaN, never 0
        assert ds.tags()["source_item"] == "S2X_T36RTV_2025-04-17"


def test_cached_outputs_reused_only_with_matching_fingerprint(scene):
    cfg = load_config("config/default.yaml")
    run_core(cfg, scene / "manifest.json", scene / "out")
    again = run_core(cfg, scene / "manifest.json", scene / "out")["qa"]
    assert again["reused_cached_output"].all()
    cfg["quality"]["scl_usable_classes"] = [4, 5]  # policy change -> must recompute
    changed = run_core(cfg, scene / "manifest.json", scene / "out")["qa"]
    assert not changed["reused_cached_output"].any()


def test_repeatable_outputs(scene):
    cfg = load_config("config/default.yaml")
    a = run_core(cfg, scene / "manifest.json", scene / "o1", force=True)["qa"].drop(
        columns=["seconds", "reused_cached_output"]
    )
    b = run_core(cfg, scene / "manifest.json", scene / "o2", force=True)["qa"].drop(
        columns=["seconds", "reused_cached_output"]
    )
    pd.testing.assert_frame_equal(a, b)


def test_benchmark_end_to_end_on_synthetic_run(scene):
    from deltawatch.benchmark import BenchmarkError, run_benchmark
    from deltawatch.manifest import load_manifest

    cfg = load_config("config/default.yaml")
    run_core(cfg, scene / "manifest.json", scene / "out")
    cfg["benchmark"].update(
        block_px=3, validation={"date": "2025-04-05", "seed": 1}, test={"date": "2025-04-17", "seed": 2}
    )
    res = run_benchmark(cfg, load_manifest(scene / "manifest.json"), scene / "out", scene / "bench")
    assert res["validation"]["scores"]["latest"]["n_predicted"] == 0  # no earlier context: abstain
    t = res["test"]["scores"]["latest"]
    assert t["coverage"] == 1.0 and t["mae"] == 0.0  # constant scene: exact persistence
    assert (scene / "bench" / "benchmark_results.json").exists() and (
        scene / "bench" / "benchmark_test_panel.png"
    ).exists()
    cfg["benchmark"]["test"]["seed"] = 1
    with pytest.raises(BenchmarkError, match="different seeds"):
        run_benchmark(cfg, load_manifest(scene / "manifest.json"), scene / "out", scene / "bench")
